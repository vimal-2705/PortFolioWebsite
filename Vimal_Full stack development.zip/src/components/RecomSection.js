import React from 'react';
import { v4 as uuid } from 'uuid';
import RecomCard from './RecomCard';

function RecomSection() {
    const recommendations = [
        {
            id: 1,
            name: "Random guy1",
            company: "ABC company",
            designation: "CEO",
            message: "He is a good engineer with ecxcellent skills",

        },
        {
            id: 2,
            name: "Random guy2",
            company: "CTS company",
            designation: "Manager",
            message: "He is a lazy boy",

        },
        {
            id: 3,
            name: "Random guy3",
            company: "RTY",
            designation: "Director",
            message: "He is a excellent full stack developer with great skills",

        },
        {
            id: 4,
            name: "Random guy4",
            company: "XYZ company",
            designation: "Assistant",
            message: "He is a good Programmer",

        },

    ];

    return (
        <div class="container-fluid mb-5 mt-3">
            <div class="row text-center py-5 d-flex flex-nowrap overflow-auto scrollbar">
                {
                    recommendations.map((recommendation) => (
                        <RecomCard key={uuid()} name={recommendation.name} designation={recommendation.designation} company={recommendation.company} message={recommendation.message} />
                    ))
                }
            </div>
        </div>
    );
}

export default RecomSection;