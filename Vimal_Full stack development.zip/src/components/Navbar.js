import React from "react";

function Navbar() {
    return (
        <nav className="navbar navbar-expand-sm fixed-top bg-white">
            <div className="container my-2">
                <a href="/" className="navbar-brand text-dark font-weight-bold"><h4> Vimal </h4></a>
                <button className="btn btn-outline-info ml-auto mr-3">
                    Contact Me
                </button>
                <button className="navbar-toggler" data-toggle="collapse" data-target="#collapseNav">
                    <span className="fa fa-bars text-dark"></span>
                </button>
                <div className="collapse navbar-collapse flex-grow-0" id="collapseNav">
                    <div className="navbar-nav">
                        <a href="/" className="nav-item nav-link text-dark h6 mx-1 my-auto">Projects</a>
                        <a href="/" className="nav-item nav-link text-dark h6 mx-1 my-auto">Blogs</a>
                    </div>
                </div>
            </div>
        </nav>
    );
}

export default Navbar;