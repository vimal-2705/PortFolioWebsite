import React from 'react';
import './App.css';
import About from './components/About';
import BlogSection from './components/BlogSection';
import Footer from './components/Footer';
import Navbar from './components/Navbar';
import ProjectSection from './components/ProjectSection';
import RecomSection from './components/RecomSection';
import SkillSection from './components/SkillSection';
import Title from './components/Title';

function App() {
  return (
    <div>
      <Navbar />
      <Title name="VIMAL" leadText="I am a freelancer developer" />
      <RecomSection />
      <SkillSection />
      <ProjectSection />
      <About />
      <BlogSection />
      <Footer />
    </div>
  )
}

export default App;
